from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError 
from flask_cors import CORS
from sqlalchemy import event
from flask_mail import Mail, Message
from sqlalchemy import update
import logging

app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:@localhost:3306/leave_application'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'tech2.tsvglobal@gmail.com'
app.config['MAIL_PASSWORD'] = 'ggnr rycb jilv iqsk'
app.config['DEBUG'] = True

mail = Mail(app)
db = SQLAlchemy(app)
logging.basicConfig(level=logging.INFO)

class Leave(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sno = db.Column(db.Integer, nullable=False)
    employee_name = db.Column(db.String(255))
    employee_id = db.Column(db.String(255))
    doj = db.Column(db.Date)
    department = db.Column(db.String(255))
    office = db.Column(db.String(255))
    leave_type = db.Column(db.String(255))
    leave_from = db.Column(db.Date)
    leave_to = db.Column(db.Date)
    num_days_hours = db.Column(db.String(255))
    leave_category = db.Column(db.String(255))
    applicant_signature = db.Column(db.String(255))
    signature_date = db.Column(db.Date)
    reporting_manager_signature = db.Column(db.String(255))

    def __init__(self, **kwargs):
        super(Leave, self).__init__(**kwargs)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)
    usertype=db.Column(db.String(255),nullable=False)

    def __repr__(self):
        return f'<User {self.email}>'

# Event listener to generate serial number before insert
@event.listens_for(Leave, 'before_insert')
def before_leave_insert(mapper, connection, target):
    # Get the current highest serial number in the database
    max_sno = db.session.query(db.func.max(Leave.sno)).scalar()
    # If max_sno is None (no records yet), start with 1, otherwise increment by 1
    target.sno = max_sno + 1 if max_sno is not None else 1

@app.route('/')
def home():
    return render_template('Login.html')


@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    # Query the User table to find a user with matching email and password
    user = User.query.filter_by(email=email, password=password).first()

    if user:
        # Check user type
        if user.usertype == 'Employee':
            # Redirect to TSV Leave Application page
            return jsonify({'success': True, 'redirect': url_for('leave_application_form')})
        elif user.usertype == 'Admin':
            # Redirect to TSV Leave Data page
            return jsonify({'success': True, 'redirect': url_for('leave_data')})
        else:
            # Invalid user type
            return jsonify({'success': False, 'message': 'Invalid user type'})
    else:
        # Login failed
        return jsonify({'success': False, 'message': 'Something went Wrong.Please try Again!!'})

    

@app.route('/TSV_Leave_Application')
def leave_application_form():
    return render_template('TSV Leave Application.html')


@app.route('/TSV_Leave_Data')
def leave_data():
    try:
        # Fetch all leave records from the database
        leave_records = Leave.query.all()
        return render_template('TSV Leave Data.html', leaves=leave_records)
    except Exception as e:
        logging.error(f"Error retrieving leave data: {e}")
        return jsonify({'error': 'Failed to retrieve leave data'})


@app.route('/delete_leave/<int:id>', methods=['DELETE'])
def delete_leave(id):
    try:
        # Find the leave record by its ID
        leave_record = Leave.query.get(id)

        # If the record does not exist, return an error response
        if not leave_record:
            return jsonify({'status': 'error', 'message': 'Leave record not found'})

        # Delete the record from the database
        db.session.delete(leave_record)
        db.session.commit()
        
        # Reassign serial numbers to maintain sequence
        # Fetch all leave records
        leave_records = Leave.query.order_by(Leave.id).all()
        
        # Update serial numbers based on the remaining records
        for index, record in enumerate(leave_records, start=1):
            record.sno = index
        
        # Commit changes to the database
        db.session.commit()

        # Return a success response
        return jsonify({'status': 'success', 'message': 'Leave record deleted successfully'})
    except SQLAlchemyError as e:
        # Log any errors that occur during the deletion process
        app.logger.error(f"Error deleting leave record: {str(e)}")
        db.session.rollback()
        return jsonify({'status': 'error', 'message': 'Failed to delete leave record'})
    finally:
        db.session.close()


@app.route('/submit_leave', methods=['POST'])
def submit_leave():
    try:
        data = request.json
        app.logger.info(f"Received form data: {data}")  
        leave = Leave(

            employee_name=data.get('employee_name'),
            employee_id=data.get('employee_id'),
            doj=data.get('doj'),
            department=data.get('department'),
            office=data.get('office'),
            leave_type=data.get('leaveType'),
            leave_from=data.get('from'),
            leave_to=data.get('to'),
            num_days_hours=data.get('numDaysHours'),
            leave_category=data.get('leavecategory'),
            applicant_signature=data.get('applicantSignature'),
            signature_date=data.get('signatureDate'),
            reporting_manager_signature=data.get('reportingManagerSignature')
        )
        db.session.add(leave)
        db.session.commit()

        send_email(data)

        return jsonify({'message': 'Leave application received. Wishing you a restful break and a speedy return!'})
    except Exception as e:
        logging.error(f"Error submitting leave application: {e}")
        return jsonify({'error': 'Failed to submit leave application'})


@app.route('/send_email', methods=['POST'])
def send_email():
    try:
        data = request.json
        recipients = ['akashmercy218@gmail.com', 'akashveera403@gmail.com']  # Add more email addresses as needed
        msg = Message('Leave Application Submitted', sender='tech2.tsvglobal@gmail.com', recipients=recipients)
        msg.body = f"""
        Employee Name: {data.get('employee_name')}
        Employee ID: {data.get('employee_id')}
        Date of Joining (DOJ): {data.get('doj')}
        Department: {data.get('department')}
        Office: {data.get('office')}
        Leave Type: {data.get('leaveType')}
        From: {data.get('from')}
        To: {data.get('to')}
        No of Days/Hours: {data.get('numDaysHours')}
        Leave Category: {data.get('leavecategory')}
        Applicant’s Signature: {data.get('applicantSignature')}
        Signature Date: {data.get('signatureDate')}
        Signature of Reporting Manager/Lead: {data.get('reportingManagerSignature')}
        """
        mail.send(msg)
        app.logger.info("Email sent successfully")
        return jsonify({'message': 'Email sent successfully'})
    except Exception as e:
        app.logger.error(f"Error sending email: {e}")
        return jsonify({'error': 'Failed to send email'}), 500


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
