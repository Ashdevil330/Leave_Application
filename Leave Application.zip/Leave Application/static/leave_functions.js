// leave_functions.js

function deleteLeave(leaveId) {
    if (confirm('Are you sure you want to delete this leave record?')) {
        fetch(`/delete_leave/${leaveId}`, {
            method: 'DELETE',
        })
        .then(response => {
            if (response.ok) {
                return response.json();  
            } else {
                throw new Error('Failed to delete leave record');  // Throw an error for non-OK status
            }
        })
        .then(data => {
            alert(data.message);
            location.reload(); // Reload the page after deletion
        })
        .catch(error => {
            console.error('Error deleting leave record:', error);
            alert('Failed to delete leave record');
        });
    }
}
